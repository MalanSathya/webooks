
import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Books')

def lambda_handler(event, context):
    data = json.loads(event['body'])

    try:
        response = table.put_item(
            Item=data,
            ConditionExpression="attribute_not_exists(Title)"
        )
        return {
            'statusCode': 201,
            'body': json.dumps({'message': 'Book added'})
        }
    except ClientError as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': str(e)})
        }
