
# import json
# import boto3
# from botocore.exceptions import ClientError

# dynamodb = boto3.resource('dynamodb')
# table = dynamodb.Table('Books')

# def lambda_handler(event, context):
#     data = json.loads(event['body'])

#     try:
#         response = table.put_item(
#             Item=data,
#             ConditionExpression="attribute_not_exists(Title)"
#         )
#         return {
#             'statusCode': 201,
#             'body': json.dumps({'message': 'Book added'})
#         }
#     except ClientError as e:
#         return {
#             'statusCode': 400,
#             'body': json.dumps({'error': str(e)})
#         }

import json
import boto3
from botocore.exceptions import ClientError
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Books')

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))
    
    try:
        data = event['body'] if isinstance(event['body'], dict) else json.loads(event['body'], parse_float=Decimal)
    except Exception as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': f'Invalid body format: {str(e)}'})
        }

    try:
        table.put_item(
            Item=data,
            ConditionExpression="attribute_not_exists(Title)"
        )
        return {
            'statusCode': 201,
            'body': json.dumps({'message': 'Book added'})
        }
    except ClientError as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': str(e)})
        }

