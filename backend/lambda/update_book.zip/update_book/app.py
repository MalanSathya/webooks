
import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Books')

def lambda_handler(event, context):
    title = event['pathParameters']['title']
    data = json.loads(event['body'])

    try:
        response = table.update_item(
            Key={'Title': title},
            UpdateExpression="set Authors=:a, Publisher=:p, Year=:y",
            ExpressionAttributeValues={
                ':a': data['Authors'],
                ':p': data['Publisher'],
                ':y': data['Year']
            },
            ConditionExpression="attribute_exists(Title)",
            ReturnValues="UPDATED_NEW"
        )
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Book updated', 'updated': response['Attributes']})
        }
    except ClientError as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': str(e)})
        }
