
import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Books')

def lambda_handler(event, context):
    title = event['pathParameters']['title']

    response = table.delete_item(
        Key={'Title': title}
    )
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Book deleted'})
    }
